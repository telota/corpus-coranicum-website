-------------------------------------------------- ----------------------
    CONTENTS

       1. ABOUT QALAM ARABIYA 4.0
       2. DISTRIBUTION, COPYRIGHT
       3. INSTALLATION, UNINSTALLATION
       4. CONTACT THE AUTHOR
       5. PROBLEMS/HELP
   -------------------------------------------------- ----------------------

   -------------------------------------------------- ----------------------
    1. ABOUT Qalam Arabiya 4.0
   -------------------------------------------------- ----------------------

    This is version 4.0 of a package with an Arabic keyboard
    layout and relevant installation instructions for use for
    Arabists, Islamic scholars etc... The keyboard layout is expanded
    about the possibility of using pointless graphemes.

   -------------------------------------------------- ----------------------
    2. DISTRIBUTION, COPYRIGHT
   -------------------------------------------------- ----------------------

    Qalam Arabiya 4.0 Copyright �2022 Tobias J. Jocham

    Qalam Arabiya 4.0 may be used both privately and commercially
    Environment can be used without payment (�freeware�) as long as the
    The following restrictions must be observed:

    The author Tobias J. Jocham assumes no liability for errors,
    which arise directly or indirectly from the use of this software.

    Qalam Arabiya 4.0 may not be used for military applications or for
    related purposes (weapons development, armaments, etc.).

    Qalam Arabiya 4.0 may be freely distributed in a non-commercial manner,
    if the distribution is in the form of the zip file 'QalamArabiya4.0.zip'.

    Qalam Arabiya 4.0 may only be distributed commercially if
    if the author Tobias J. Jocham expressly agrees to the distribution.

   -------------------------------------------------- ----------------------
    3. INSTALLATION, UNINSTALLATION
   -------------------------------------------------- ----------------------

    To install Qalam Arabiya 4.0, unpack the zip archive and read the PDF
    "QalamArabiya4.0_EN.pdf". The necessary background information is presented
    and the individual setup steps are shown in detail using screenshots.
    If problems occur during or after the installation, please first read the
    manual "QalamArabiya4.0_EN.pdf" again in detail. To uninstall, please first
    deactivate the keyboard layout to be removed via the settings of the "Text
    services and input languages" and only then uninstall the corresponding
    keyboard layout via the Control Panel->Software.

   -------------------------------------------------- ----------------------
    4. CONTACT THE AUTHOR
   -------------------------------------------------- ----------------------

    Postal address:

      Tobias J. Jocham
      Kirchgasse 3
      12043 Berlin
      - Germany -

    E-mail:
      tobias.j.jocham@gmx.de

   -------------------------------------------------- ----------------------
    5. PROBLEMS/HELP
   -------------------------------------------------- ----------------------

    The handout "QalamArabiya4.0_EN.pdf" contains detailed instructions for
    installing and setting up and using the keyboard layouts. If you have any
    problems, please consult the relevant sections in the handout before
    contacting the author.